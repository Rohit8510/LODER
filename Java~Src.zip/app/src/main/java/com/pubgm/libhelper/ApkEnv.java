package com.pubgm.libhelper;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.RemoteException;
import androidx.core.app.ActivityCompat;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.core.env.BEnvironment;
import com.pubgm.BoxApplication;
import com.pubgm.R;
import com.pubgm.utils.FLog;
import static com.pubgm.Config.GAME_LIST_PKG;
import com.pubgm.utils.FileUtils;
import java.io.File;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class ApkEnv {
    File obbContaine;
    
    private static ApkEnv singleton;
    
    public static ApkEnv getInstance() {
        if (singleton == null) {
            singleton = new ApkEnv();
        }
        return singleton;
    }
    
    public ApplicationInfo getApplicationInfo(String packageName) {
        ApplicationInfo applicationInfo = null;
        try {
        	applicationInfo = BoxApplication.get().getPackageManager().getApplicationInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException err) {
        	FLog.error(err.getMessage());
            BoxApplication.get().toast(err.getMessage());
            return null;
        }
        return applicationInfo;
    }
    
    public ApplicationInfo getApplicationInfoContainer(String packageName) {
    if (!isInstalled(packageName)) {
        BoxApplication.get().toast("App not install, install first");
        return null;
    }

    try {
        ApplicationInfo applicationInfo =
                BlackBoxCore.getBPackageManager()
                            .getApplicationInfo(packageName, 0, 0);

        return applicationInfo;
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}
    
    public void launchApk(String packageName) {
        if (!isInstalled(packageName)) {
            BoxApplication.get().toast("Client not installed");
            return;
        }
        try {
            BlackBoxCore.get().launchApk(packageName, 0);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public boolean isInstalled(String packageName) {
    	try {
            return BlackBoxCore.get().isInstalled(packageName, 0);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
    
    public boolean isInstalled2(String packageName) {
    	try {
            return BlackBoxCore.get() != null && BlackBoxCore.get().isInstalled(packageName, 0);
        } catch (Throwable e) {
            return false;
        }

    }

    public boolean isRunning(String packageName) {
    /*	try {
            return BlackBoxCore.get().isAppRunning(packageName, 0);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
*/
return false;
    }

    public boolean installByFile(String packageName) {
        ApplicationInfo applicationInfo = getApplicationInfo(packageName);
        if (applicationInfo == null) {
            return false;
        }
        try {
            return BlackBoxCore.get().installPackageAsUser(applicationInfo.sourceDir, 0).success;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public boolean installByPackage(String packageName) {
        try {
            return BlackBoxCore.get().installPackageAsUser(packageName, 0).success;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void unInstallApp(String packageName) {
        try {
            BlackBoxCore.get().uninstallPackageAsUser(packageName, 0);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void stopRunningApp(String packageName) {
        try {
            BlackBoxCore.get().stopPackage(packageName, 0);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public File getObbContainerPath(String packageName) {
    return new File(
        "/storage/emulated/0/blackbox/Android/obb",
        packageName
    );
}
    
    public boolean tryAddLoader(String packageName) {

        ApplicationInfo applicationInfo = getApplicationInfoContainer(packageName);
        if (applicationInfo == null) {
            FLog.error("Error, Application Info");
            return false;
        }

        String target = "libpubgm.so";

        if (packageName.equals(GAME_LIST_PKG[0])) {
            target = "libbgmi.so";
        } else if (packageName.equals(GAME_LIST_PKG[1])) {
            target = "libpubgm.so";
        } else if (packageName.equals(GAME_LIST_PKG[2])) {
            target = "libkorea.so";
        } else if (packageName.equals(GAME_LIST_PKG[3])) {
            target = "libvietnam.so";
        } else if (packageName.equals(GAME_LIST_PKG[4])) {
            target = "libtaiwan.so";
        }

        File loader = new File(true ? new File(BoxApplication.get().getFilesDir(), "loader").toString() : BoxApplication.get().getApplicationInfo().nativeLibraryDir,target);
        File loaderDest = new File(applicationInfo.nativeLibraryDir, packageName.equals("com.miraclegames.farlight84") ? "libfarlight.so" : "libAkAudioVisiual.so");
        if (loaderDest.exists()) loaderDest.delete();

        try {
            if (FileUtils.copy(loader.toString(), loaderDest.toString())) {
                File file = new File(BlackBoxCore.getContext().getFilesDir(), "loader/" + target);
                if (file.exists()) {
                    System.load(file.getAbsolutePath());
                }
                return true;
            }
        } catch (Exception err) {
            FLog.error(err.getMessage());
            return false;
        }

        return false;
    }
    
}
